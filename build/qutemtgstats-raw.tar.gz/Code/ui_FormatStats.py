# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'UIs/FormatStats.ui'
#
# Created: Fri Nov 21 09:38:52 2014
#      by: pyside-uic 0.2.15 running on PySide 1.2.1
#
# WARNING! All changes made in this file will be lost!

from PySide import QtCore, QtGui

class Ui_FormatStats(object):
    def setupUi(self, FormatStats):
        FormatStats.setObjectName("FormatStats")
        FormatStats.resize(400, 350)
        self.verticalLayout = QtGui.QVBoxLayout(FormatStats)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QtGui.QScrollArea(FormatStats)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QtGui.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 380, 273))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.scrollAreaWidgetContents)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)
        self.buttonFrame = QtGui.QFrame(FormatStats)
        self.buttonFrame.setFrameShape(QtGui.QFrame.StyledPanel)
        self.buttonFrame.setFrameShadow(QtGui.QFrame.Raised)
        self.buttonFrame.setObjectName("buttonFrame")
        self.horizontalLayout = QtGui.QHBoxLayout(self.buttonFrame)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.exportStatsButton = QtGui.QPushButton(self.buttonFrame)
        self.exportStatsButton.setObjectName("exportStatsButton")
        self.horizontalLayout.addWidget(self.exportStatsButton)
        self.adjustFiltersButton = QtGui.QPushButton(self.buttonFrame)
        self.adjustFiltersButton.setEnabled(True)
        self.adjustFiltersButton.setObjectName("adjustFiltersButton")
        self.horizontalLayout.addWidget(self.adjustFiltersButton)
        self.cancelButton = QtGui.QPushButton(self.buttonFrame)
        self.cancelButton.setObjectName("cancelButton")
        self.horizontalLayout.addWidget(self.cancelButton)
        self.verticalLayout.addWidget(self.buttonFrame)

        self.retranslateUi(FormatStats)
        QtCore.QMetaObject.connectSlotsByName(FormatStats)

    def retranslateUi(self, FormatStats):
        FormatStats.setWindowTitle(QtGui.QApplication.translate("FormatStats", "Qute Format Stats", None, QtGui.QApplication.UnicodeUTF8))
        self.exportStatsButton.setText(QtGui.QApplication.translate("FormatStats", "Export Stats", None, QtGui.QApplication.UnicodeUTF8))
        self.adjustFiltersButton.setText(QtGui.QApplication.translate("FormatStats", "Adjust Filters", None, QtGui.QApplication.UnicodeUTF8))
        self.cancelButton.setText(QtGui.QApplication.translate("FormatStats", "Done", None, QtGui.QApplication.UnicodeUTF8))

